<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us | Employee Task Management System</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap (agar already project me hai to duplicate mat add karna) -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <style>
        body{
            background:#f5f7fb;
        }
        .contact-box{
            background:#fff;
            border-radius:15px;
            padding:30px;
            box-shadow:0 10px 30px rgba(0,0,0,0.08);
        }
        .contact-info{
            background:linear-gradient(135deg,#0f172a,#020617);
            color:#fff;
            border-radius:15px;
            padding:30px;
            height:100%;
        }
        .contact-info a{
            color:#22c55e;
            text-decoration:none;
        }
        .btn-send{
            background:#22c55e;
            border:none;
            padding:12px 30px;
            border-radius:30px;
            color:#fff;
            font-weight:600;
        }
        .btn-send:hover{
            background:#16a34a;
        }
        input, textarea{
    color: #111 !important;   /* 🔥 TEXT COLOR FIX */
    background: #f1f5f9 !important;
}

        
        textarea{
            border-radius:15px !important;
        }
    </style>
</head>

<body>

<div class="container my-5">
    <div class="row g-4">

        <!-- LEFT : CONTACT INFO -->
        <div class="col-md-4">
            <div class="contact-info">
                <h4>Contact Information</h4>
                <hr>

                <p>📞 
                    <a href="tel:+919155825629">+91 91558 25629</a>
                </p>

                <p>📧 
                    <a href="mailto:rayaadarsh528@gmail.com">
                        rayaadarsh528@gmail.com
                    </a>
                </p>

                <p>📍 Patna, Bihar, India</p>
            </div>
        </div>

        <!-- RIGHT : CONTACT FORM -->
        <div class="col-md-8">
            <div class="contact-box">
                <h4>Send Message</h4>
                <hr>

                <!-- 🔴 FORM START -->
               <form action="https://formspree.io/f/xreqpvkr" method="POST">

    <input type="hidden" name="_subject" value="New Contact Message - ETMS">

    <div class="row">
        <div class="col-md-6 mb-3">
            <input type="text" name="name" class="form-control"
                   placeholder="Your Name" required>
        </div>

        <div class="col-md-6 mb-3">
            <input type="email" name="email" class="form-control"
                   placeholder="Your Email" required>
        </div>
    </div>

    <div class="mb-3">
        <input type="text" name="purpose" class="form-control"
               placeholder="Purpose (Support / Query)">
    </div>

    <div class="mb-4">
        <textarea name="message" class="form-control" rows="5"
                  placeholder="Write your message..." required></textarea>
    </div>

    <button type="submit" class="btn btn-send">
        Send Message
    </button>

</form>

                <!-- 🔴 FORM END -->

            </div>
        </div>

    </div>
</div>

</body>
</html>
