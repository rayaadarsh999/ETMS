<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(strlen($_SESSION['etmsempid'])==0){
    header('location:logout.php');
} else {

$empid=$_SESSION['etmsempid'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Employee Task Management System | Completed Task</title>

<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="style.css" />
<link rel="stylesheet" href="css/responsive.css" />
<link rel="stylesheet" href="css/colors.css" />
<link rel="stylesheet" href="css/custom.css" />

<style>
.main_heading{
    background:#1f2937;
    color:#fff;
    padding:15px;
    font-weight:600;
}
.table thead{
    background:#343a40;
    color:#fff;
}
.table tbody tr:hover{
    background:#f8f9fa !important;
}
.badge-completed{
    background:#28a745;
    padding:6px 12px;
    border-radius:4px;
    font-size:13px;
    color:#fff;
}
.viewbtn{
    background:#007bff;
    color:#fff;
    padding:6px 14px;
    border-radius:4px;
    text-decoration:none;
}
.viewbtn:hover{
    background:#0056b3;
    color:#fff;
}
</style>
</head>

<body class="inner_page tables_page">
<div class="full_container">
<div class="inner_container">

<?php include_once('includes/sidebar.php');?>
<div id="content">
<?php include_once('includes/header.php');?>

<div class="midde_cont">
<div class="container-fluid">

<div class="row column_title">
<div class="col-md-12">
<div class="page_title">
<h2>Completed Task</h2>
</div>
</div>
</div>

<div class="white_shd full margin_bottom_30">
<div class="main_heading">
VIEW COMPLETED TASK
</div>

<div class="padding_infor_info">
<div class="table-responsive">

<table class="table table-bordered">
<thead>
<tr>
<th>S.No</th>
<th>Task Title</th>
<th>Department</th>
<th>Assign Date</th>
<th>End Date</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php
$sql="SELECT tbltask.ID as tid,
      tbltask.TaskTitle,
      tbltask.Status,
      tbltask.TaskEnddate,
      tbltask.TaskAssigndate,
      tbldepartment.DepartmentName
      FROM tbltask
      JOIN tbldepartment ON tbldepartment.ID=tbltask.DeptID
      WHERE tbltask.AssignTaskto=:empid 
      AND LOWER(TRIM(tbltask.Status))='completed'
      ORDER BY tbltask.ID DESC";

$query=$dbh->prepare($sql);
$query->bindParam(':empid',$empid,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;

if($query->rowCount()>0){
foreach($results as $row){
?>

<tr>
<td><?php echo $cnt;?></td>
<td><?php echo htmlentities($row->TaskTitle);?></td>
<td><?php echo htmlentities($row->DepartmentName);?></td>
<td><?php echo htmlentities($row->TaskAssigndate);?></td>
<td><?php echo htmlentities($row->TaskEnddate);?></td>
<td><span class="badge-completed">Completed</span></td>
<td>
<a href="view-task.php?viewid=<?php echo htmlentities($row->tid);?>" class="viewbtn">View</a>
</td>
</tr>

<?php $cnt++; }} else { ?>

<tr>
<td colspan="7" align="center">No Completed Task Found</td>
</tr>

<?php } ?>

</tbody>
</table>

</div>
</div>
</div>

</div>
</div>

<?php include_once('includes/footer.php');?>

</div>
</div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>

<?php } ?>
