<?php
include('includes/dbconnection.php');

if (!empty($_POST['deptid'])) {

    $deptid = intval($_POST['deptid']);

    echo '<option value="">Select Employee</option>';

    $sql = "SELECT ID, EmpName FROM tblemployee WHERE DeptID = :deptid";
    $query = $dbh->prepare($sql);
    $query->bindParam(':deptid', $deptid, PDO::PARAM_INT);
    $query->execute();

    if ($query->rowCount() > 0) {
        foreach ($query->fetchAll(PDO::FETCH_OBJ) as $row) {
            echo '<option value="'.$row->ID.'">'.$row->EmpName.'</option>';
        }
    } else {
        echo '<option value="">No Employee Found</option>';
    }
}
?>
