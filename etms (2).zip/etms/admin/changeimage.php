<?php
session_start();
include('includes/dbconnection.php');

if (strlen($_SESSION['etmsaid']) == 0) {
    header('location:logout.php');
    exit();
}

$aid = $_SESSION['etmsaid'];

if (isset($_POST['submit'])) {

    $imgname = $_FILES["profilepic"]["name"];
    $extension = substr($imgname, strlen($imgname)-4, strlen($imgname));

    $allowed_extensions = array(".jpg",".jpeg",".png",".gif");

    if (!in_array($extension,$allowed_extensions)) {
        echo "<script>alert('Invalid format. Only jpg / jpeg / png / gif allowed');</script>";
    } else {

        $newname = md5($imgname.time()).$extension;
        move_uploaded_file($_FILES["profilepic"]["tmp_name"], "images/".$newname);

        $sql = "UPDATE tbladmin SET ProfilePic=:pic WHERE ID=:aid";
        $query = $dbh->prepare($sql);
        $query->bindParam(':pic',$newname,PDO::PARAM_STR);
        $query->bindParam(':aid',$aid,PDO::PARAM_STR);
        $query->execute();

        echo "<script>alert('Profile image updated successfully');</script>";
        echo "<script>window.location.href='profile.php'</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Change Profile Image</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body>
<div class="container mt-5">
<div class="row justify-content-center">
<div class="col-md-6">

<div class="card">
<div class="card-header text-center">
<h4>Change Profile Image</h4>
</div>

<div class="card-body text-center">
<form method="post" enctype="multipart/form-data">

<input type="file" name="profilepic" class="form-control mb-3" required>

<button type="submit" name="submit" class="btn btn-primary">
Upload Image
</button>

</form>
</div>
</div>

</div>
</div>
</div>
</body>
</html>
